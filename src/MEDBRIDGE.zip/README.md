# MedBridge – Medical Equipment Sharing Portal

## 1. Project Overview

MedBridge is a web-based Medical Equipment Sharing Portal developed to make medical equipment more accessible through sharing, donating, lending and renting.

The platform provides a common place where individuals, NGOs and hospitals can connect to share available medical equipment. It aims to reduce the difficulty of finding necessary medical equipment and encourage its reuse.

## 2. Objectives

- Provide a platform for sharing medical equipment.
- Connect donors, NGOs and hospitals.
- Allow users to browse available medical equipment.
- Support equipment donation, lending and renting.
- Provide a simple interface for managing equipment and requests.
- Encourage the reuse of medical equipment.

## 3. Technologies Used

### Frontend
- HTML5 – Structure of web pages.
- CSS3 – Styling and responsive layouts.
- JavaScript – User interactions and application functionality.

### Backend and Database
- Supabase – Database management and authentication.
- SQL – Database schema and table structure.

### Development Tools
- Visual Studio Code – Code editor.
- Git and GitHub – Source code management.
- Web Browser – Running and testing the application.

## 4. Main Modules and Features

- **Home:** Introduction to the MedBridge platform.
- **User Authentication:** Login and signup functionality.
- **Equipment:** Browse available medical equipment.
- **Donate:** Provide equipment donation details.
- **Requests:** View and manage equipment requests.
- **Cart:** Add and view selected equipment.
- **Dashboard:** Access the available dashboard features.
- **About:** Information about the project.

## 5. Equipment Categories

The platform organizes medical equipment into the following categories:

- Diagnostic
- Monitoring
- Mobility
- Surgical
- Respiratory
- Other

Equipment conditions include New, Good, Used and Needs Repair.

Sharing options include Donate, Lend and Rent.

## 6. Project Folder Structure

MedBridge/
│
├── index.html
├── style.css
├── script.js
│
├── assets/
│
├── database/
│   └── schema.sql
│
├── screenshots/
│
└── README.md

Note: The folder structure may vary depending on the final project files.

## 7. Installation and Setup

### Prerequisites

- A computer with a web browser.
- Visual Studio Code.
- A Supabase account.
- Internet connection.

### Steps to Run the Project

1. Download or clone the MedBridge project repository.
2. Extract the ZIP folder if downloaded.
3. Open the project folder in Visual Studio Code.
4. Configure the Supabase project using your own project credentials.
5. Ensure that the required database tables are created in Supabase.
6. Open the index.html file using a local development server such as VS Code Live Server.
7. Access the application through the browser.

## 8. Supabase Configuration

MedBridge uses Supabase for database management and user authentication.

To configure Supabase:

1. Create a project on the Supabase platform.
2. Open Project Settings and locate the API credentials.
3. Configure the Supabase project URL and publishable/anon key in the application as required by the existing code.
4. Create the required database tables using the SQL file available in the database folder.
5. Configure the necessary authentication and database permissions.

Important: Never upload Supabase secret keys, service-role keys or database passwords to a public repository.

## 9. Database

The project uses Supabase as its database platform.

The database schema file (database/schema.sql) contains the SQL definitions for the project's database structure, where applicable.

It can be used as a reference when setting up the database for another environment.

## 10. Future Scope

- Improve equipment search and filtering.
- Enhance equipment request management.
- Improve the user dashboard.
- Add additional notifications and communication features.
- Further improve the mobile-responsive interface.

## 11. Project Information

**Project Name:** MedBridge – Medical Equipment Sharing Portal

**Project Type:** B.Tech Project-Based Learning (PBL)

**Domain:** Web Development

**Technologies:** HTML, CSS, JavaScript and Supabase

## 12. Conclusion

MedBridge aims to provide a simple and accessible platform for medical equipment sharing. By connecting individuals, NGOs and hospitals, the project encourages the reuse of medical equipment and helps make essential resources easier to find.

---

Developed as part of the Bachelor of Technology Project-Based Learning (PBL).